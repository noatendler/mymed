require('./database');
require('./server');
// require('./sendEmail');